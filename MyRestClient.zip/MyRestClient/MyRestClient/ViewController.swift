//
//  ViewController.swift
//  MyRestClient
//
//  Created by berufs team on 08/07/2017.
//  Copyright © 2017 berufs. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource {

    let textCellIndicator = "countryCell"
    
    @IBOutlet weak var countryTableView: UITableView!
    
    var fetchedCountry = [Country]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        countryTableView.dataSource = self
        
        parseData()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override var prefersStatusBarHidden: Bool{
        return true
    }

    //Start
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return fetchedCountry.count
    }
    
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = countryTableView.dequeueReusableCell(withIdentifier: textCellIndicator)
        
        cell?.textLabel?.text = fetchedCountry[indexPath.row].country
        cell?.detailTextLabel?.text = fetchedCountry[indexPath.row].capital
        
        return cell!
    }
    //End
    
    
    func parseData(){
        
        fetchedCountry = []
        //setting my url
        let url = "https://restcountries.eu/rest/v1/all"
        
        //create request variable
        var request = URLRequest(url: URL(string: url)!)
        
        //
        request.httpMethod = "GET"
        
        let configuration = URLSessionConfiguration.default
        
        let sesion = URLSession(configuration: configuration, delegate: nil, delegateQueue: OperationQueue.main)
        
        let task = sesion.dataTask(with: request){
         (data, response, error) in
            if error != nil {
                print("error")
            }else{
                do{
                    let fetchedData = try JSONSerialization.jsonObject(with: data!, options: .mutableLeaves)
                    as! NSArray
                    
                    print("-----------getting data--------------")
                    print(fetchedData)
                    print("-----------ending data--------------")
                    
                    for eachFetchedCountry in fetchedData{
                        let eachCountry = eachFetchedCountry as! [String: Any]
                        
                        let country = eachCountry["alpha2Code"] as! String
                        let capital = eachCountry["demonym"] as! String
                        
                        self.fetchedCountry.append(Country(country: country, capital: capital))
                        
                        print("-----------getting new data--------------")
                        print(self.fetchedCountry)
                        print("-----------ending  new data--------------")
                        
                        self.countryTableView.reloadData()
                        
                    }
                    
                }catch{
                    print("error 2")
                }
            }
        }
        
        task.resume()
    }
    
    
}


class Country {
    var country: String
    var capital: String
    
    init(country: String, capital: String){
        self.country = country
        self.capital = capital
    }
}




